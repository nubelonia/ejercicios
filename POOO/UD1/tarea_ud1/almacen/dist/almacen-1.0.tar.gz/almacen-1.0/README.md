# Paquete almacen

Gestión de productos en un almacén.