from setuptools import setup 

setup(
    name="almacen",
    version="1.0",
    description="Gestión de productos en un almacén",
    author="Manu Benítez López",    
    packages=['almacen']
)